import javax.swing.*;
import java.awt.*;
public class boxlay extends JFrame
{
	JButton b[]=new JButton[4];
	String lab[]={"one","two","three","four"};
	public boxlay()
	{
		setTitle("My box layout win");
		setLayout(new BoxLayout(getContentPane(),BoxLayout.X_AXIS));
		for(int i=0;i<b.length;i++)
		{
			b[i]=new JButton(lab[2]);
			b[i].setAlignmentY(Component.CENTER_ALIGNMENT); 
			add(b[i]);
			// add(Box.createHorizontalGlue());
			add(Box.createHorizontalStrut(10));
		}
		setSize(400,400);
		setVisible(true);
	}
	public static void main(String args[])
	{
		boxlay ob=new boxlay();
	}
}