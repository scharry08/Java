import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class GB8 extends JPanel
{
	
	public GB8()
	{
		setLayout(new GridBagLayout());

		GridBagConstraints c=new GridBagConstraints();
		c.fill=GridBagConstraints.BOTH;
		
		c.weightx=1;

		add(new JButton("1"),c);
		add(new JButton("2"),c);
		add(new JButton("3"),c);
		add(new JButton("4"),c);

		c.gridwidth=GridBagConstraints.REMAINDER;
		add(new JButton("5"),c);

		c.gridwidth=1;
		c.weightx=0;

		add(new JButton("A"),c);
		add(new JButton("B"),c);
		add(new JButton("C"),c);

		c.gridwidth=GridBagConstraints.REMAINDER;

		add(new JButton("D"),c);
		c.gridwidth=1;

		add(new JButton("a"),c);
		c.gridwidth=GridBagConstraints.RELATIVE;
		add(new JButton("b"),c);
		c.gridwidth=GridBagConstraints.REMAINDER;
		add(new JButton("c"),c);
		c.gridwidth=1;
	}
	public static void main(String args[])
	{
		JFrame f=new JFrame("GridBag 8 Example");
		f.add(new GB8());
		f.addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent w)
			{
				f.dispose();
			}
		});
		f.pack();
		f.setVisible(true);
	}
}
		

		
		