import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class GB7 extends JPanel
{
	
	public GB7()
	{
		setLayout(new GridBagLayout());

		GridBagConstraints c=new GridBagConstraints();
		c.fill=GridBagConstraints.BOTH;
		c.gridx=0;
		c.gridy=0;

		c.gridwidth=1;
		c.gridheight=1;
		add(new JButton("first"),c);

		c.gridx=1;
		c.gridy=0;

		c.gridwidth=3;
		c.gridheight=1;
		add(new JButton("second"),c);

		c.gridx=0;
		c.gridy=1;

		c.gridwidth=1;
		c.gridheight=1;
		add(new JScrollBar(JScrollBar.VERTICAL),c);

		c.gridx=1;
		c.gridy=1;

		c.gridwidth=2;
		c.gridheight=2;
		add(new JButton("third"),c);

		c.gridx=3;
		c.gridy=1;

		c.gridwidth=1;
		c.gridheight=3;
		add(new JScrollBar(JScrollBar.VERTICAL),c);

		c.gridx=0;
		c.gridy=2;

		c.gridwidth=1;
		c.gridheight=1;
		add(new JButton("fouth"),c);

		c.gridx=0;
		c.gridy=3;

		c.gridwidth=2;
		c.gridheight=1;
		add(new JButton("fifth"),c);

		c.gridx=0;
		c.gridy=4;

		c.gridwidth=1;
		c.gridheight=1;
		add(new JScrollBar(JScrollBar.HORIZONTAL),c);

		c.gridx=1;
		c.gridy=4;

		c.gridwidth=1;
		c.gridheight=1;
		add(new JScrollBar(JScrollBar.HORIZONTAL),c);

		c.gridx=2;
		c.gridy=4;

		c.gridwidth=1;
		c.gridheight=1;
		add(new JScrollBar(JScrollBar.HORIZONTAL),c);

		c.gridx=3;
		c.gridy=4;

		c.gridwidth=1;
		c.gridheight=1;
		add(new JScrollBar(JScrollBar.HORIZONTAL),c);

	}
	public static void main(String args[])
	{
		JFrame f=new JFrame("GridBag 7 Example");
		f.add(new GB7());
		f.addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent w)
			{
				f.dispose();
			}
		});
		f.pack();
		f.setVisible(true);
	}
}
		

		
		