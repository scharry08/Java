import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class GB6 extends JPanel
{
	
	public GB6()
	{
		Font f=new Font("Serif",0,36);
		setFont(f);

		setLayout(new GridBagLayout());

		GridBagConstraints c=new GridBagConstraints();
		c.gridx=0;
		c.gridy=0;

		add(new JButton("TL"),c);
		c.gridx=1;
		add(new JButton("Top Middle"),c);
		c.gridx=2;
		add(new JButton("TR"),c);

		c.gridx=0;
		c.gridy=1;
		
		add(new JButton("ML"),c);

		c.gridx=2;
	
		add(new JButton("MR"),c);

		c.gridx=0;
		c.gridy=2;

		add(new JButton("BL"),c);
		c.gridx=1;

		add(new JButton("Bottom Middle"),c);
		c.gridx=2;

		add(new JButton("BR"),c);

		JButton b=new JButton("x");
		b.setFont(new Font("SansSerif",0,10));

		c.gridx=1;
		c.gridy=1;

		//c.fill=GridBagConstraints.HORIZONTAL;
		//c.fill=GridBagConstraints.VERTICAL;
		c.fill=GridBagConstraints.BOTH;

		add(b,c);
	}
	public static void main(String args[])
	{
		JFrame f=new JFrame("GridBag 6 Example");
		f.add(new GB6());
		f.addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent w)
			{
				f.dispose();
			}
		});
		f.pack();
		f.setVisible(true);
	}
}
		

		
		