import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class GB1 extends JPanel
{
	private JPanel tallPanel1=new JPanel();
	private JPanel tallPanel2=new JPanel();
	public GB1()
	{
		tallPanel1.setLayout(new GridLayout(3,1));
		tallPanel1.add(new JButton("Press"));
		tallPanel1.add(new JButton("Any"));
		tallPanel1.add(new JButton("One"));

		tallPanel2.setLayout(new GridLayout(3,1));
		tallPanel2.add(new JButton("Don't"));
		tallPanel2.add(new JButton("Press"));
		tallPanel2.add(new JButton("these"));		

		setLayout(new GridBagLayout());

		GridBagConstraints c=new GridBagConstraints();
		c.gridx=0;
		c.gridy=0;
		add(new JButton("topleft"),c);
		c.gridx=1;
		add(new JButton("topmiddle"),c);
		c.gridx=2;
		add(new JButton("topright"),c);

		c.gridx=0;
		c.gridy=1;
		add(new JButton("lefthandsidemiddle"),c);
		c.gridx=1;
		add(tallPanel1,c);

		c.gridy=2;
		add(new JButton("bottomcenter"),c);
		c.gridx=2;
		add(tallPanel2,c);
	}
	public static void main(String args[])
	{
		JFrame f=new JFrame("GridBag 1 Example");
		f.add(new GB1());
		f.addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent w)
			{
				f.dispose();
			}
		});
		f.pack();
		f.setVisible(true);
	}
}
		

		
		