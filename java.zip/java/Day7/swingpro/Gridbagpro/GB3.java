import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class GB3 extends JPanel
{
	private JPanel tallJPanel1=new JPanel();
	private JPanel tallJPanel2=new JPanel();
	public GB3()
	{
		tallJPanel1.setLayout(new GridLayout(3,1));
		tallJPanel1.add(new JButton("Press"));
		tallJPanel1.add(new JButton("Any"));
		tallJPanel1.add(new JButton("One"));

		tallJPanel2.setLayout(new GridLayout(3,1));
		tallJPanel2.add(new JButton("Don't"));
		tallJPanel2.add(new JButton("Press"));
		tallJPanel2.add(new JButton("these"));		

		setLayout(new GridBagLayout());

		GridBagConstraints c=new GridBagConstraints();
		c.gridx=0;
		c.gridy=0;

		c.weightx=9; // this is a stretchy column (column 0)
		add(new JButton("topleft"),c);
		c.gridx=1;

		c.weightx=9; // this is a stretchy column (column 1)
		add(new JButton("topmiddle"),c);
		c.gridx=2;
		
		c.weightx=18; // this is a stretchy column (column 2)

		add(new JButton("topright"),c);


		c.gridx=0;
		c.gridy=1;

		c.weightx=0; // reset the stretchiness
		add(new JButton("lefthandsidemiddle"),c);
		c.gridx=1;
		
		add(tallJPanel1,c);

		c.gridy=2;

		c.weighty=1.0; // this is a stretchy row (row 2)

		add(new JButton("bottomcenter"),c);
		c.gridx=2;

		

		add(tallJPanel2,c);
	}
	public static void main(String args[])
	{
		JFrame f=new JFrame("GridBag 1 Example");
		f.add(new GB3());
		f.addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent w)
			{
				f.dispose();
			}
		});
		f.pack();
		f.setVisible(true);
	}
}
		

		
		