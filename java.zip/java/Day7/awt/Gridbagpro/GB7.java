import java.awt.*;
public class GB7 extends Panel
{
	
	public GB7()
	{
		setLayout(new GridBagLayout());

		GridBagConstraints c=new GridBagConstraints();
		c.fill=GridBagConstraints.BOTH;
		c.gridx=0;
		c.gridy=0;

		c.gridwidth=1;
		c.gridheight=1;
		add(new Button("first"),c);

		c.gridx=1;
		c.gridy=0;

		c.gridwidth=3;
		c.gridheight=1;
		add(new Button("second"),c);

		c.gridx=0;
		c.gridy=1;

		c.gridwidth=1;
		c.gridheight=1;
		add(new Scrollbar(Scrollbar.VERTICAL),c);

		c.gridx=1;
		c.gridy=1;

		c.gridwidth=2;
		c.gridheight=2;
		add(new Button("third"),c);

		c.gridx=3;
		c.gridy=1;

		c.gridwidth=1;
		c.gridheight=3;
		add(new Scrollbar(Scrollbar.VERTICAL),c);

		c.gridx=0;
		c.gridy=2;

		c.gridwidth=1;
		c.gridheight=1;
		add(new Button("fouth"),c);

		c.gridx=0;
		c.gridy=3;

		c.gridwidth=2;
		c.gridheight=1;
		add(new Button("fifth"),c);

		c.gridx=0;
		c.gridy=4;

		c.gridwidth=1;
		c.gridheight=1;
		add(new Scrollbar(Scrollbar.HORIZONTAL),c);

		c.gridx=1;
		c.gridy=4;

		c.gridwidth=1;
		c.gridheight=1;
		add(new Scrollbar(Scrollbar.HORIZONTAL),c);

		c.gridx=2;
		c.gridy=4;

		c.gridwidth=1;
		c.gridheight=1;
		add(new Scrollbar(Scrollbar.HORIZONTAL),c);

		c.gridx=3;
		c.gridy=4;

		c.gridwidth=1;
		c.gridheight=1;
		add(new Scrollbar(Scrollbar.HORIZONTAL),c);

	}
	public static void main(String args[])
	{
		Frame f=new Frame("GridBag 7 Example");
		f.add(new GB7(),BorderLayout.CENTER);
		f.pack();
		f.setVisible(true);
	}
}
		

		
		