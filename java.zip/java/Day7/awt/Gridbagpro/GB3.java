import java.awt.*;
public class GB3 extends Panel
{
	private Panel tallPanel1=new Panel();
	private Panel tallPanel2=new Panel();
	public GB3()
	{
		tallPanel1.setLayout(new GridLayout(3,1));
		tallPanel1.add(new Button("Press"));
		tallPanel1.add(new Button("Any"));
		tallPanel1.add(new Button("One"));

		tallPanel2.setLayout(new GridLayout(3,1));
		tallPanel2.add(new Button("Don't"));
		tallPanel2.add(new Button("Press"));
		tallPanel2.add(new Button("these"));		

		setLayout(new GridBagLayout());

		GridBagConstraints c=new GridBagConstraints();
		c.gridx=0;
		c.gridy=0;

		c.weightx=9; // this is a stretchy column (column 0)
		add(new Button("topleft"),c);
		c.gridx=1;

		c.weightx=9; // this is a stretchy column (column 1)
		add(new Button("topmiddle"),c);
		c.gridx=2;
		
		c.weightx=18; // this is a stretchy column (column 2)

		add(new Button("topright"),c);


		c.gridx=0;
		c.gridy=1;

		c.weightx=0; // reset the stretchiness
		add(new Button("lefthandsidemiddle"),c);
		c.gridx=1;
		
		add(tallPanel1,c);

		c.gridy=2;

		c.weighty=1.0; // this is a stretchy row (row 2)

		add(new Button("bottomcenter"),c);
		c.gridx=2;

		

		add(tallPanel2,c);
	}
	public static void main(String args[])
	{
		Frame f=new Frame("GridBag 1 Example");
		f.add(new GB3());
		f.pack();
		f.setVisible(true);
	}
}
		

		
		