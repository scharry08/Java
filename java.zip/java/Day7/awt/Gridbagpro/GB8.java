import java.awt.*;
public class GB8 extends Panel
{
	
	public GB8()
	{
		setLayout(new GridBagLayout());

		GridBagConstraints c=new GridBagConstraints();
		c.fill=GridBagConstraints.BOTH;
		
		c.weightx=1;

		add(new Button("1"),c);
		add(new Button("2"),c);
		add(new Button("3"),c);
		add(new Button("4"),c);

		c.gridwidth=GridBagConstraints.REMAINDER;
		add(new Button("5"),c);

		c.gridwidth=1;
		c.weightx=0;

		add(new Button("A"),c);
		add(new Button("B"),c);
		add(new Button("C"),c);

		c.gridwidth=GridBagConstraints.REMAINDER;

		add(new Button("D"),c);
		c.gridwidth=1;

		add(new Button("a"),c);
		c.gridwidth=GridBagConstraints.RELATIVE;
		add(new Button("b"),c);
		c.gridwidth=GridBagConstraints.REMAINDER;
		add(new Button("c"),c);
		c.gridwidth=1;
	}
	public static void main(String args[])
	{
		Frame f=new Frame("GridBag 8 Example");
		f.add(new GB8(),BorderLayout.CENTER);
		f.pack();
		f.setVisible(true);
	}
}
		

		
		