import java.awt.*;
public class GB5 extends Panel
{
	
	public GB5()
	{
		Font f=new Font("Serif",0,36);
		setFont(f);

		setLayout(new GridBagLayout());

		GridBagConstraints c=new GridBagConstraints();
		c.gridx=0;
		c.gridy=0;

		add(new Button("TL"),c);
		c.gridx=1;
		add(new Button("Top Middle"),c);
		c.gridx=2;
		add(new Button("TR"),c);

		c.gridx=0;
		c.gridy=1;
		
		add(new Button("ML"),c);

		c.gridx=2;
	
		add(new Button("MR"),c);

		c.gridx=0;
		c.gridy=2;

		add(new Button("BL"),c);
		c.gridx=1;

		add(new Button("Bottom Middle"),c);
		c.gridx=2;

		add(new Button("BR"),c);

		Button b=new Button("x");
		b.setFont(new Font("SansSerif",0,10));

		c.gridx=1;
		c.gridy=1;

		//c.anchor=GridBagConstraints.NORTHWEST;
		c.anchor=GridBagConstraints.NORTHEAST;

		add(b,c);
	}
	public static void main(String args[])
	{
		Frame f=new Frame("GridBag 4 Example");
		f.add(new GB5(),BorderLayout.CENTER);
		f.pack();
		f.setVisible(true);
	}
}
		

		
		