public class Example1
{
	public static void main(String args[])
	{
		int arr[]=new int[4];
		System.out.println("Array created");
		arr[4]=10;
		System.out.println("Array assigned");
	}
}