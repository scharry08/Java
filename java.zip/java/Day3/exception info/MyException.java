public class MyException extends Exception
{
	public MyException(String mess)
	{
		super(mess);
	}
}
