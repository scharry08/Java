
@MyAnnotation(value=100)
public class Trial 
{

}

@MyAnnotation(value=200)
class Sample
{
	
}
