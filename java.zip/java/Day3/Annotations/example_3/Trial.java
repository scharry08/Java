
@MyAnnotation(value=100)
public class Trial 
{

}

class Sample extends Trial
{
	
}
