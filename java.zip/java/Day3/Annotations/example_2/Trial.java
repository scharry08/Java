package core1;
public class Trial 
{
@MyAnnotation(getFirst="hello",getSecond=200)
	public void disp()
	{
	System.out.println("in disp");
	}
}
