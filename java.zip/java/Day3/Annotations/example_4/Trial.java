
@MyAnnotation(value=500)
public class Trial 
{

}
@MyAnnotation
class Sample 
{
	
}
