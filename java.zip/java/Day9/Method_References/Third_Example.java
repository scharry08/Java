/*

When it encounters Employee::new, the compiler assumes the right constructor to call based on the context in which the constructor reference appears. Here, EmployeeProvider provider provides this context. Because this functional interface supplies a single abstract method whose parameter list matches the second Employee constructor, the compiler chooses that constructor. The constructor is then called (and the Employee object returned) by the subsequent getEmployee() method call.

*/



class Employee
{
   String name;
   Integer age;

   Employee()
   {
      name = "Shri-420";
      age = 20;
   }

   Employee(String name, Integer age)
   {
      this.name = name;
      this.age = age;
   }
}

@FunctionalInterface
interface EmployeeProvider
{
   Employee getEmployee(String name, Integer age);

 //  Employee getEmployee(); try with this also
}

public class ConstructorRefDemo
{
   public static void main(String[] args)
   {
      EmployeeProvider provider = Employee::new;
      Employee emp = provider.getEmployee("John Doe",25);
      System.out.println("Name:\t"+ emp.name);
      System.out.println("Age: \t"+ emp.age);

      
      /*try following code in case of no-arg getEmployee() */


     /* Employee emp = provider.getEmployee();
      System.out.println("Name:\t"+ emp.name);
      System.out.println("Age: \t"+ emp.age);*/
   }
}








