var myvar = Java.type('java.lang.String'); 

   var result = new myvar("welcome").length(); 
       
print(result);