/* 
* File Name : script.js
*
* @function - Print a given name
* @param {String} name
* @param {int}	age
* @return String
*/
var fun1 = function (name,age) 
{
print ('Hello from JS, ' + name+'  '+age);
return "Hi from JS";
};

var fun2=function()
{
	print("welcome to fun2");
};











