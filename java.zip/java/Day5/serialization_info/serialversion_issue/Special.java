import java.io.*;
public class Special implements Serializable
{
	//String str="hello";
	private int num=100;
//static final long serialVersionUID = -3126998878902358585L;

	public String toString()
	{
		return ""+num;
		//return str;			
	}
}
