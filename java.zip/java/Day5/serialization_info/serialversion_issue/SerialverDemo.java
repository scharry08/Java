import java.io.*;
public class SerialverDemo implements Serializable
{
	public static final long serialVersionUID=100L;
	char ch;
	
}


/* serialver SerialverDemo

	above command will print 
	"static final long serialVersionUID=100L"

	now make some changes i.e. add some members inside class or modify existing members, save and compile the java file.

	serialver SerialverDemo

		it will still print

	"static final long serialVersionUID=100L"

*/