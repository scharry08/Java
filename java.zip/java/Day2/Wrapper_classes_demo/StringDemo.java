public class StringDemo
{
	public static void main(String args[])
	{
		String s1="hello";
	
		String s2=new String("hello");

		System.out.println(s1);
		System.out.println(s2);
	}
}
	