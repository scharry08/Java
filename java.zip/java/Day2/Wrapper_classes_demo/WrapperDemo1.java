public class WrapperDemo1
{
	public static void main(String args[])
	{
		// how do u wrap primitive inside the wrapper class ?

		int num=100;
		Integer ob=new Integer(num);
		System.out.println(ob);
	}
}
	