import static java.lang.System.*;
import java.util.*;
public class ScannerDemo2
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(in);
		
	out.printf("Enter name");
		out.printf("%s\n",sc.next());
out.printf("%s\n","Enter number");	out.printf("%d\n",sc.nextInt());

		out.println("Enter boolean");
		out.printf("%b\n",sc.nextBoolean());

out.printf("%s\n","Enter character");
		out.printf("%c\n",sc.next().charAt(0));
	}
}






































