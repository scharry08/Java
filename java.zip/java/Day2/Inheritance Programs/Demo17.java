final class base
{

}
class sub1 extends base   
{

}
public class Demo17
{
	public static void main(String args[])
	{
		sub1 s1=new sub1(); 

	}
}