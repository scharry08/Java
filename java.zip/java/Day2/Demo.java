/*
When the intern method is invoked, if the pool already contains a string equal to this String object as determined by the equals(Object) method, then the string from the pool is returned. Otherwise, this String object is added to the pool and a reference to this String object is returned. 

It follows that for any two strings s and t, s.intern() == t.intern() is true if and only if s.equals(t) is true. 
*/

public class Demo 
{
	
	public static void main(String args[])
	{
		String s1="hello";
		String s2="hello";
		String s3=new String("hello");
		if(s1==s2)
		{
			System.out.println("s1 and s2 are ==");
		}
		else
		{
			System.out.println("s1 and s2 are not ==");
		}
		if(s1==s3)
		{
			System.out.println("s1 and s3 are ==");
		}
		else
		{
			System.out.println("s1 and s3 are not ==");
		}
		if(s1==s3.intern())
		{
			System.out.println("s1 and s3 are ==");
		}
		else
		{
			System.out.println("s1 and s3 are not ==");
		}
		if(s1==s3)
		{
			System.out.println("s1 and s3 are ==");
		}
		else
		{
			System.out.println("s1 and s3 are not ==");
		}
		String s4="hel";
		if(s1==s4+"lo")
		{
			System.out.println("s1 and s4 are ==");
		}
		else
		{
			System.out.println("s1 and s4 are not ==");
		}
		String s5="hel"+"lo";
		if(s1==s5)
		{
			System.out.println("s1 and s5 are ==");
		}
		else
		{
			System.out.println("s1 and s5 are not ==");
		}
		
		
	}
}