import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Collections;

public class Second {

   public static void main(String a[]){
	   
    
	   List<String> mylist=Collections.synchronizedList(new ArrayList<String>());

       //Adding elements to synchronized ArrayList
       mylist.add("Pen");
       mylist.add("NoteBook");
       mylist.add("Ink");

       System.out.println("Iterating synchronized ArrayList:");
       Thread thread1=new Thread(new Runnable() {

    	   public void run() 
	{
        synchronized(mylist)
	{
       Iterator<String> iterator = mylist.iterator(); 
   
       while (iterator.hasNext())
       {
          System.out.println(iterator.next());
          try
          {
       	   Thread.sleep(100);
          }
          catch(InterruptedException ie)
          {
       	   ie.printStackTrace();
          }
       }
      	   }
	}
       });
       thread1.start();
       Thread thread2=new Thread(new Runnable() {

    	 public void run() 
	{
       synchronized(mylist)
	{
       mylist.add("erasure");
       mylist.add("Pencil");
	}
       }
       });
       thread2.start();

	try
	{
		thread1.join();
		thread2.join();
	}
	catch(InterruptedException ie)
	{
		ie.printStackTrace();
	}
System.out.println("At the end mylist is\t"+mylist);
   }
}


/*

output:

Iterating synchronized ArrayList:
Pen
Exception in thread "Thread-0" java.util.ConcurrentModificationException
	at java.util.ArrayList$Itr.checkForComodification(Unknown Source)
	at java.util.ArrayList$Itr.next(Unknown Source)
	at core1.Details$1.run(Details.java:29)
	at java.lang.Thread.run(Unknown Source)

*/