import java.util.*;
import static java.lang.System.*;
public class HashSetDemo
{
	public static void main(String args[])
	{
		HashSet <String>hs=new HashSet<String>();
		hs.add("b");
		hs.add("c");
		hs.add("d");
		hs.add("e");
		hs.add("f");
		hs.add("g");
		out.println("contents of hs  "+hs);
	}
}	
		