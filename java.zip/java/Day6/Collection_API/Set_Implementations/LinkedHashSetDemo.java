import java.util.*;
import static java.lang.System.*;
public class LinkedHashSetDemo
{
	public static void main(String args[])
	{
		LinkedHashSet <String>hs=new LinkedHashSet<String>();
		hs.add("b");
		hs.add("c");
		hs.add("d");
		hs.add("e");
		hs.add("f");
		hs.add("g");
		out.println("contents of hs  "+hs);
	}
}	
		