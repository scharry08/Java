import java.util.*;
import static java.lang.System.*;
public class TreeSetDemo
{
	public static void main(String  args[])
	{
		TreeSet <String>t=new TreeSet<String>();
		t.add("a");
		t.add("b");
		t.add("c");
		t.add("d");
		t.add("e");
		out.println("contents are  "+t);
	}
}		
