import java.util.*;
public class MyComparator implements Comparator<Integer> {
   public int compare(Integer a, Integer b) {
      //
	return a.compareTo(b);
   }
}