public class Th9 implements Runnable
{
	static Thread ref;
	public void run()
	{
		
			for(int i=0;i<5;i++)
			{	
				System.out.println("Hello"+i);
if(Thread.currentThread().getName().equals("First"))
{
			try
			{
				Thread.sleep(200);
			}
			catch(InterruptedException ie)
{
	ie.printStackTrace();
}
}
else
{
	ref.interrupt();
}
		}
	}
	public static void main(String args[])
	{
		//ref=Thread.currentThread();
		Th9 ob=new Th9();
		Th9 ob1=new Th9();
		
		Thread t1=new Thread(ob,"First");
		Thread t2=new Thread(ob,"Second");
		ref=t1;
		t1.start();
		t2.start();
		
		
		System.out.println("Both the threads are over");
	}
}





