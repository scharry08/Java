/* class lock and object lock are independent */
public class ClassLock5 implements Runnable
{
	static Class cs;
	 static void disp1()
	 {
	String name=Thread.currentThread().getName();
		synchronized(cs)
		{
		for(int i=0;i<5;i++)
		{
			System.out.println("static "+i+"\t"+name);
		}
		}
	}
	synchronized void disp2()
	{
	String name=Thread.currentThread().getName();
		for(int i=0;i<5;i++)
		{
			System.out.println("Hello  \t"+i+"\t"+name);
		}
	}
	public void run()
	{
		if(Thread.currentThread().getName().equals("First"))
{
		disp1();
		disp2();
}
else
{
	disp2();
	disp1();
}
	
	}
	public static void main(String args[])throws Exception
	{
		cs=Class.forName("ClassLock5");
		ClassLock5 c=new ClassLock5();
		Thread t1=new Thread(c,"First");
		Thread t2=new Thread(c,"Second");
		
		t1.start();
		t2.start();
	}
}



/*

Possible output of above code:

D:\nitin\exp>java ClassLock5
static 0        First
static 1        First
static 2        First
static 3        First
static 4        First
Hello   0       Second
Hello   1       Second
Hello   2       Second
Hello   3       Second
Hello   4       Second
static 0        Second
static 1        Second
static 2        Second
static 3        Second
static 4        Second
Hello   0       First
Hello   1       First
Hello   2       First
Hello   3       First
Hello   4       First

*/










