/* class lock and object lock are independent */
public class ClassLock4 implements Runnable
{
	static Class cs;
	 static void disp1()
	 {
		synchronized(cs)
		{
		for(int i=0;i<5;i++)
		{
			System.out.println("static "+i);
		}
		}
	}
	void disp2()
	{
		for(int i=0;i<5;i++)
		{
			System.out.println("Hello  \t"+i);
			try
			{
				Thread.sleep(100);
			}
			catch(InterruptedException ie)
			{
			}
		}
	}
	public void run()
	{
		disp1();
		disp2();
	}
	public static void main(String args[])throws Exception
	{
		cs=Class.forName("ClassLock4");
		ClassLock4 c=new ClassLock4();
		ClassLock4 c1=new ClassLock4();
		Thread t1=new Thread(c);
		Thread t2=new Thread(c1);
		t1.start();
		t2.start();
	}
}