/* class lock and object lock are independent */
public class ClassLock6 implements Runnable
{
	static Class cs;
	 static void disp1()
	 {
	String name=Thread.currentThread().getName();
		synchronized(cs)
		{
		for(int i=0;i<5;i++)
		{
if(i==3 || i==4)
{
	cs.notifyAll();
}
if(i==3)
{

	try
	{
		cs.wait();
	}
	catch(InterruptedException ie)
	{
	}
}
System.out.println("static "+i+"\t"+name);

	try
	{
		Thread.sleep(200);
	}
	catch(InterruptedException ie)
	{
	}

		}
		}
	}
	synchronized void disp2()
	{
	String name=Thread.currentThread().getName();
		for(int i=0;i<5;i++)
		{
			System.out.println("Hello  \t"+i+"\t"+name);
			try
			{
				Thread.sleep(100);
			}
			catch(InterruptedException ie)
			{
			}
		}
	}
	public void run()
	{
		disp1();
		disp2();
	}
	public static void main(String args[])throws Exception
	{
		cs=Class.forName("ClassLock6");
		ClassLock6 c=new ClassLock6();
		Thread t1=new Thread(c,"First");
		Thread t2=new Thread(c,"Second");
		
		t1.start();
		t2.start();
	}
}