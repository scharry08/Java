#include<iostream>
using namespace std;

template<class T>
struct node
{
      T data;
      node<T> *next;
};

template<class T>
class Queue
{
      private:
              node<T> *front,*rear,*cur,*temp;
      public:
	      Queue();
		  ~Queue();
		  void insert();
		  void remove();
		  void disp();
};

template<class T>
Queue<T>::Queue()
{
               front=rear=cur=temp=NULL;
}

template<class T>
Queue<T>::~Queue()
{
			if(front!=NULL)
			{         
				do
                {
							cur=front;
					        front=cur->next;
							delete cur;                                       
                }while(front!=NULL);
			}
}

template<class T>
void Queue<T>::insert()
{

                     T a;
        
                     cout<<"\nEnter data Of New Node (Enter 0 To Have other options):";

                     cin>>a;

                     while(a)
                     {
                             temp=new node<T>;
                             temp->data=a;	
                             temp->next=NULL;
                             if(front==NULL)
							 {
	                             front=temp;
								 rear=temp;
							 }
							 else
							 {
								rear->next=temp;
								rear=temp;
							 }                        
                     	 cout<<"\nEnter data Of New Node (Enter 0 To Have other options):";
						 cin>>a;
					 }
}
template<class T>
void Queue<T>::remove()
{
     if(front==NULL)
     {
         cout<<"\n Sorry Queue is empty..";
     }
     else
     {
          cur=front;
		  cout<<"Deleted member is\t"<<front->data<<endl;
		  front=cur->next;
		  delete cur;
	 }
}

template<class T>
void Queue<T>::disp()
{
     if(front==NULL)
     {
         cout<<"\n Sorry Queue is empty..";
     }
     else
     {
            cur=front;
			while(cur!=NULL)
			{
				cout<<endl<<cur->data;
				cur=cur->next;
			}
     }
}

