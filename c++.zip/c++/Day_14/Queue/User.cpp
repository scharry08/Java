#include "queue.h"

int main()
{
    int n;
    Queue <int> l;

	l.insert();

	do
	{

                   cout<<"\n 1.display \n2.remove \n3.Exit \n";

                   cout<<"\n Enter your option : ";

                   cin>>n;

                   switch(n)

                   {

                            case 1: l.disp();

                            break;

							case 2: l.remove();

                            break;

							case 3: exit(0);
                         
                   }
    }while(n<=3);
    return 0;
}