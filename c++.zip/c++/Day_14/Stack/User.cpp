#include "stack.h"

int main()
{
    int n;
    stack <int> l;

	l.push();

	do
	{

                   cout<<"\n 1.peek \n2.display  \n3.pop \n4.Exit \n";

                   cout<<"\n Enter your option : ";

                   cin>>n;

                   switch(n)

                   {

                            case 1: l.peek();

                            break;

							case 2: l.disp();

                            break;

							case 3: l.pop();

                            break;

                           case 4: exit(0);                      
                   }
    }while(n<=4);
    return 0;
}