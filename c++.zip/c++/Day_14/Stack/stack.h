#include<iostream>
using namespace std;

template<class T>
struct node
{
      T data;
      node<T> *next;
};

template<class T>
class stack
{
      private:
              node<T> *top,*cur,*temp;
      public:
	      stack();
		  ~stack();
		  void push();
		  void peek();
		  void disp();
		  void pop();
};

template<class T>
stack<T>::stack()
{
               top=cur=temp=NULL;
}

template<class T>
stack<T>::~stack()
{
			if(top!=NULL)
			{         
				do
                {
							cur=top;
					        top=cur->next;
							delete cur;                                       
                }while(top!=NULL);
			}
}

template<class T>
void stack<T>::push()
{

                     T a;
        
                     cout<<"\nEnter data Of New Node (Enter 0 To Have other options):";

                     cin>>a;

                     while(a)
                     {
                             temp=new node<T>;
                             temp->data=a;	
                             temp->next=NULL;
                             if(top==NULL)
							 {
	                             top=temp;
							 }
							 else
							 {
								temp->next=top;
								top=temp;
							 }                        
                     	 cout<<"\nEnter data Of New Node (Enter 0 To Have other options):";
						 cin>>a;
					 }
}
template<class T>
void stack<T>::peek()
{
     if(top==NULL)
     {
         cout<<"\n Sorry stack is empty..";
     }
     else
     {
          cout<<endl<<top->data;
	 }
}

template<class T>
void stack<T>::disp()
{
     if(top==NULL)
     {
         cout<<"\n Sorry stack is empty..";
     }
     else
     {
            cur=top;
			while(cur!=NULL)
			{
				cout<<endl<<cur->data;
				cur=cur->next;
			}
     }
}

template<class T>
void stack<T>::pop()
{
                 if(top==NULL)
                 {
                                cout<<"\nSorry stack is empty.";
								return;
                 }
				 else
				 {
					cur=top;
					cout<<"Popped off\t"<<top->data<<endl;
					top=cur->next;
					delete cur;
				 }
}
