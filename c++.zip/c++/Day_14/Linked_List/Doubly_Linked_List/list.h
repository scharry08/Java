#include<iostream>
using namespace std;

template<class T>
struct node
{
      T data;
      node<T> *next,*prev;
};

template<class T>
class list
{
      private:
              node<T> *start,*last,*cur,*prev1,*temp;
      public:
	      list();
		  ~list();
		  void createlist();
		  void deletion();
		  void insertion();
		  void ascDisp();
		  void descDisp();
		  void modify();
		  void sort();
};

template<class T>
list<T>::list()
{
               start=last=cur=prev1=temp=NULL;
}

template<class T>
list<T>::~list()
{
                prev1=start;
				do
                {
					        cur=prev1->next;
							delete prev1;
                            prev1=cur;                    
                }while(cur!=NULL);
}

template<class T>
void list<T>::createlist()
{

                     T a;
        
                     cout<<"\nEnter data Of New Node (Enter 0 To Have other options):";

                     cin>>a;

                     while(a)
                     {
                             temp=new node<T>;
                             temp->data=a;
							 temp->prev=NULL;
                             temp->next=NULL;
                             if(start==NULL)
							 {
	                             start=temp;
								 last=temp;
							 }
							 else
							 {
								last->next=temp;
								temp->prev=last;
								last=temp;
							 }

                             cout<<"\nEnter data Of New Node (Enter 0 To Have other options):";
	                         cin>>a;
                     }
}
template<class T>
void list<T>::ascDisp()
{
     if(start==NULL)
     {
         cout<<"\n Sorry list is empty..";
     }
     else
     {
            cur=start;
			while(cur!=NULL)
			{
				cout<<endl<<cur->data;
				cur=cur->next;
			}
     }
}
template<class T>
void list<T>::descDisp()
{
     if(start==NULL)
     {
         cout<<"\n Sorry list is empty..";
     }
     else
     {
            cur=last;
			while(cur!=NULL)
			{
				cout<<endl<<cur->data;
				cur=cur->prev;
			}
     }
}
template<class T>
void list<T>::insertion()
{
			T a;
            cout<<"\nEnter data Of New Node";
			cin>>a;
			temp=new node<T>;
			temp->data=a;
			temp->prev=NULL;
			temp->next=NULL;
			if(temp->data < start->data)
			{
				temp->next=start;
				start->prev=temp;
				start=temp;
			}
			else if(temp->data > last->data)
			{
				last->next=temp;
				temp->prev=last;
				last=temp;
			}
			else
			{
				cur=start;
				while(temp->data > cur->data)
				{
					cur=cur->next;
				}
				temp->next=cur;
				temp->prev=cur->prev;
				(cur->prev)->next=temp;
				cur->prev=temp;
			
			}
}

template<class T>
void list<T>::deletion()
{
			T deldata;
			cout<<endl<<"Enter data to delete\n";
			cin>>deldata;
                 if(start==NULL)
                 {
                                cout<<"\nSorry list is empty.";
								return;
                 }
				 else
				 {
					if(deldata==start->data)
			{
				cur=start;
				start=cur->next;
				start->prev=NULL;
				delete cur;
			}
			
			else
			{
			    cur=start;
				while(deldata!=cur->data)
				{
					cur=cur->next;
				}
		(cur->prev)->next=cur->next;
if(cur==last)
{
	last=cur->prev;
}
else
{
	(cur->next)->prev=cur->prev;
}
				delete cur;
			}
		 }
	 }


template<class T>
void list<T>:: modify()
{
	if(start==NULL)
    {
          cout<<"\nSorry list is empty.";
		  return;
    }
	T olddata,newdata;
	cout<<endl<<"enter old data.\n";
	cin>>olddata;
	cout<<endl<<"Enter new data\n";
	cin>>newdata;
	cur=start;
	int flag=1;
	while(olddata != cur->data)
	{
		cur=cur->next;
	if(cur==NULL)
		{
		cout<<"data doesn't exists"<<endl;
			flag=0;
			break;
		}
	}
	if(flag!=0)
	cur->data=newdata;
}

template<class T>
void list<T>::sort()
{
			T temp;
			for(prev1=start;prev1->next!=NULL;prev1=prev1->next)
			{
				for(cur=prev1->next;cur!=NULL;cur=cur->next)
				{
					if(prev1->data > cur->data)
					{
						temp=prev1->data;
						prev1->data=cur->data;
						cur->data=temp;
					}
				}
			}
}