#include "list.h"

int main()
{
    int n;
    list <int> l;

	l.createlist();

	do
	{

                   cout<<"\n 1.Insertion \n2.AscDisplay  \3.DescDisplay \n4.Insert \n5.Sort \n6.Delete \n7.Modify  \n8.Exit \n";

                   cout<<"\n Enter your option : ";

                   cin>>n;

                   switch(n)

                   {

                            case 1: l.insertion();

                            break;

							case 2: l.ascDisp();

                            break;

							case 3: l.descDisp();

                            break;

                            case 4: l.insertion();

                            break;
							
							case 5: l.sort();

                            break;

							case 6: l.deletion();

                            break;

							case 7: l.modify();

                            break;

							case 8: exit(0);                      
                   }
    }while(n<=8);
    return 0;
}