#include "list.h"

int main()
{
    int n;
    list <int> l;

	l.createlist();

	do
	{
                   cout<<"\n 1.Insertion \n2.Display \n3.Insert \n4.Sort \n5.Delete \n6.Modify  \n7.Exit \n";

                   cout<<"\n Enter your option : ";

                   cin>>n;

                   switch(n)

                   {

                            case 1: l.insertion();

                            break;

                            case 2: l.display();

                            break;

                            case 3: l.insertion();

                            break;
							
							case 4: l.sort();

                            break;

							case 5: l.deletion();

                            break;

							case 6: l.modify();

                            break;

							case 7: exit(0);                      
                   }
    }while(n<=7);
    return 0;
}
