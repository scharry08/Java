#include <iostream>     // std::cout
#include <cstdlib>      // std::exit
#include <new>          // std::set_new_handler
using namespace std;


void no_memory () 
{
  cout << "Failed to allocate memory!\n";
  exit (1);
}

int main () 
{
//check what happens when following line is commented
//  set_new_handler(no_memory);
  cout << "Attempting to allocate 1 GiB...";
  char *p=NULL;
  while(true)
 {
		 p = new char [1024*1024*1024];
 }
  //char *p=new char[200];
  cout << "Ok\n";
  delete[] p;
  return 0;
}







