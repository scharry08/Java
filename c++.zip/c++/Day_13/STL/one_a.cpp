#include<iostream>
#include<vector>
#include<conio.h>
using namespace std;
void main()
{
	vector<int> myvect;
	vector<int>::iterator myiter;
	myvect.push_back(10);
	myvect.push_back(20);
	
	myiter=myvect.begin();
	cout<<*myiter<<endl;

	cout<<"using simple pointer"<<endl;
	int **ptr=(int**)&myvect;
	int *ptr1=(int*)*ptr;
	cout<<*ptr1<<endl;
	ptr1++;
	cout<<*ptr1<<endl;
	getch();
}






