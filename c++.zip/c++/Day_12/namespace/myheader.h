namespace sp1
{
	class myclass
	{
	public:
		myclass();
		void disp();
	};
}
