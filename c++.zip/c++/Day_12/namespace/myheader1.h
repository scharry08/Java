namespace sp2
{
	class myclass
	{
	public:
		myclass();
		void disp();
	};
}