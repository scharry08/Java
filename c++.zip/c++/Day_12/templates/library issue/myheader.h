template<class type>
class myc
{
	type t;
	public:
		myc(type t)
		{
			this->t=t;
		}				
		void disp()
		{
			cout<<t<<endl;
		}
};
