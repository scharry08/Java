//Scope of a variable
//By def. scope of a variable is ltd. to a block or a function
//in which it is defined.
#include <iostream>

using namespace std;

int main()
{
    cout << "Hello World";
    system("pause");
    return 0;
    
}