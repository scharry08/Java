#include<iostream>
using namespace std;

int main()
{
	for(int i=0;i<4;i++)
	{
		cout<<i<<endl;
	}
	/*for(i=0;i<10;i++)  // Error
	{
		cout<<i<<endl;
	}*/
	for(int i=0;i<8;i++)
	{
		cout<<i<<endl;
	}
	int num=10; // variable decl anywhere
	cout<<num<<endl;

	return 0;
}