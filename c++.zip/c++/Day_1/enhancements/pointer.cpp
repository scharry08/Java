/*#include<iostream>
using namespace std;
int main()
{
	int num=10;
	
        const int *ptr=&num; //pointer to a constant
	*ptr=40; // Error 
	ptr++; // no error

	int * const ptr1=&num;  // constant pointer
	*ptr1=100;
	ptr1++;  // Error 
	int num1=20;


	const int * const ptr2=&num1; //constant pointer to a constant
;
	//*ptr2=30; Error
 //	ptr2++; Error
}**/