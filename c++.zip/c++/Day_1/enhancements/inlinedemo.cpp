#include<iostream>
using namespace std;
inline void show()
{
	cout<<"welcome to show function"<<endl;
}
int main()
{
	show();
	return 0;
}