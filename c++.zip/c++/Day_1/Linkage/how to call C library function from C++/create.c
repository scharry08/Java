#include<stdio.h>
void disp(char *message)
{
	puts(message);
}