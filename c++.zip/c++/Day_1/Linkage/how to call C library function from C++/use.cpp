#include<iostream>
#include "D:\nitin\My_C++\client\myhead.h"
using namespace std;
void main()
{
	cout<<"Before Call"<<endl;
	disp("welcome");
	cout<<"After Call\n";
}
