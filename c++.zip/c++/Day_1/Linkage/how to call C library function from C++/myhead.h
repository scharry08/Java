#ifdef __cplusplus
extern "C" {
#endif
void  disp();
#ifdef __cplusplus
}
#endif