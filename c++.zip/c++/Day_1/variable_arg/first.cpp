#include<iostream>
#include<stdarg.h>
using namespace std;
void disp(int no,...)
{
	va_list ptr;
	int i;
	va_start(ptr,no);
	for(i=0;i<no;i++)
	{
		cout<<va_arg(ptr,int)<<endl;
	}
}
int main()
{
	disp(3,10,20,30);
	disp(5,100,200,300,400,500);
	return 0;
}



