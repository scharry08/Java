#include<stdio.h>
#include<stdarg.h>
void disp(int no,...)
{
	va_list ptr;
	int i;
	va_start(ptr,no);
	for(i=0;i<no;i++)
	{
		printf("%d\n",va_arg(ptr,int));
	}
}
int main()
{
	disp(3,10,20,30);
	disp(5,100,200,300,400,500);
}

