#include<stdio.h>
#include<stdarg.h>
void disp(char *fmt,...)
{
	va_list ptr;
	int i;
	va_start(ptr,fmt);

	for(i=0;fmt[i]!='\0';i++)
	{
		switch(fmt[i])
		{
		case 'c':printf("%c\n",va_arg(ptr,char));
			break;
		case 'd':printf("%lf\n",va_arg(ptr,double));
			break;
		case 's':printf("%s\n",va_arg(ptr,char*));
			break;
		case 'i':printf("%d\n",va_arg(ptr,int));
		}
	}
}
int main()
{
	disp("sdci","welcome",10.5,'a',200);
}
















