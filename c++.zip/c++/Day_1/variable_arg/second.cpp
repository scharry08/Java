#include<iostream>
#include<stdarg.h>
using namespace std;
void disp(char *fmt,...)
{
	va_list ptr;
	int i;
	va_start(ptr,fmt);

	for(i=0;fmt[i]!='\0';i++)
	{
		switch(fmt[i])
		{
		case 'c':cout<<va_arg(ptr,char)<<endl;
			break;
		case 'd':cout<<va_arg(ptr,double)<<endl;
			break;
		case 's':cout<<va_arg(ptr,char*)<<endl;
			break;
		case 'i':cout<<va_arg(ptr,int)<<endl;
		}
	}
}
int main()
{
	disp("sdci","welcome",10.5,'a',200);
}





