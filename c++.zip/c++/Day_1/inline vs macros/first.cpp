#include<iostream.h>
/*
#define SQUARE(X) X*X
void main()
{
 int y = 3;
 int j = SQUARE(++y);
 cout<<j<<endl;
}
*/

/*
inline int square(int x)
{
	return x*x;
}
void main()
{
	int i=3,j;
	j=square(++i);
	cout<<"with inline\t"<<j<<endl;
}
*/