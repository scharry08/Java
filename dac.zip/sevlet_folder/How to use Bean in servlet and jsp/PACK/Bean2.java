package pack;
public class Bean2
{
	public int getVal()
	{
		return 100;
	}
}