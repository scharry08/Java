package pack;
public class Bean1
{
	public String getMess()
	{
		return "Welcome to Bean";
	}
}