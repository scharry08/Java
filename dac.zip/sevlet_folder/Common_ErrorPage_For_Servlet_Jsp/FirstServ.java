import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
public class FirstServ extends HttpServlet
{
	public void service(ServletRequest request,ServletResponse response)throws ServletException,IOException
	{
		PrintWriter pw=response.getWriter();
pw.println("First Servlet");
int arr[]=new int[3];
arr[3]=10;
pw.println("done");
		
	}
}
		

		