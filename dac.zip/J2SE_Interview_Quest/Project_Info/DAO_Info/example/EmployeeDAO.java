package mypack;

public interface EmployeeDAO 
{
	void insertEmployee(Employee ref);
	Employee getEmployee();
}
