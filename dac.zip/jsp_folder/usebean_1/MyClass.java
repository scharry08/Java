package beanpack;
public class MyClass
{
	public String disp()
	{
		return "welcome to MyClass disp";
	}
}