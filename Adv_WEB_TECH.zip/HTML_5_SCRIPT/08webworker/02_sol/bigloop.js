
        for (var i = 0; i <= 10000; i += 1){
   var j = i;
}
postMessage(j);
      