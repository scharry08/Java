var v=9;
function call()
{
for(i=1;i<7;i++)
{
 document.write("<h"+i+">Hello</h"+i+">");
// document.write("<font size="+i+">Hello</font>");
}


}