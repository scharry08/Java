function call()
{
document.write("hello welcome to javascript");
}
