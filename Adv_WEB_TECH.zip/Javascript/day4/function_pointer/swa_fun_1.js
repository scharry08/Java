<script>
function go(who)

document.write("hello"+who)
go("world")

</script>