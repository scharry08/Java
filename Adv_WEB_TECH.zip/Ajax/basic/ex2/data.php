<?php 
    echo 'This text was fetched from the server with Ajax and PHP.'; 
?>
