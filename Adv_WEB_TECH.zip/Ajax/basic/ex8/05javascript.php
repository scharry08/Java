<?php 


    echo 'display()'; 
?> 
