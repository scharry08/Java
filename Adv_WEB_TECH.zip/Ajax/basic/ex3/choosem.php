<?php
  if ($_REQUEST["data"] == "1") {
    echo 'You sent the server a value of 1';
  }
  if ($_REQUEST["data"] == "2") {
    echo 'You sent the server a value of 2';
  }
?>
