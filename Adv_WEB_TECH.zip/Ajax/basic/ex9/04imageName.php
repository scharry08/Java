<?php
  if ($_REQUEST["image"] == "1"){
    echo "04Image1.jpg";
  }
  if ($_REQUEST["image"] == "2"){
    echo "04Image2.jpg";
  }
?>