
<?php
$nm=$_POST["data"]["nm"];
$ps=$_POST["data"]["pass"];

  echo "welcome ".$nm ;
  
  
?>