$(document).ready(function(){
	var c=0;
  $("#btn").click(function(){
var n=$("#nm").val();
var p= $("#pas").val();

arr=$("#frm").serializeJSON();
//var arr = {"nm" : n, "pass" : p};
var url="chk.php";
console.log(arr);
alert(url)
       $.post(url,{data:arr},function(d) {
		              alert(d);
					$("#dd").html(d);
                }).fail(function(x) {
    alert( "error"+x );
  })

});
});
