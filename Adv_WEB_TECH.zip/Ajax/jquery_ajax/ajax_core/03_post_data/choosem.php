<?php
  if ($_REQUEST["d"]=="btn1") {
    echo 'You got 1st id='. $_REQUEST["d"] ;
  }
  
if ($_REQUEST["d"]=="btn2") {
    echo 'You got 2st id='. $_REQUEST["d"] ;
  }
?>
