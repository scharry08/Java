<?php
  if ($_REQUEST["d"] == "1") {
    echo 'You sent the server a value of 1';
  }
  if ($_REQUEST["g"] == "go") {
    echo 'You sent the server a value of go';
  }
?>
