<?php
$name=$_REQUEST["uname"];
$code=$_REQUEST["pwd"];

echo ("Username:" . $name . "Password:"  .$code.);
?>