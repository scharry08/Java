<?php
$fname=$_REQUEST["name"];
$city=$_REQUEST["city"];
echo "<table border='3'><tr><td>";

echo ("Dear</td><td> " . $fname . ".</td></tr><tr> ");
echo("<td>Hope you live well in </td><td>" . $city . ".</td></tr></table>");
?>
